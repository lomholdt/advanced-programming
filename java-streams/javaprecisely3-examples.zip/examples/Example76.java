// Example 76 from page 57 of Java Precisely third edition (The MIT Press 2016)
// Author: Peter Sestoft (sestoft@itu.dk)


class Example76 {
  public static void main(String[] args) {
    for (int i=1; i<=4; i++) {
      for (int j=1; j<=i; j++)
        System.out.print("*");
      System.out.println();
    }
  }
}

